# 🏥 Analizador Comparativo de Terminología Médica en Wikipedia

Este proyecto proporciona un sistema robusto y fácil de usar para analizar y comparar la terminología médica presente en múltiples artículos de Wikipedia en español. Permite extraer el contenido textual de las páginas, procesarlo mediante técnicas de procesamiento de lenguaje natural (NLP), visualizar los términos más relevantes y sus relaciones, identificar los temas principales y generar un mapa ontológico interactivo para una comprensión profunda de los conceptos médicos.

## 📌 Características Principales

* **Web Scraping Inteligente:** Extrae el texto de artículos de Wikipedia en español, optimizado para eliminar elementos no textuales como tablas, referencias, imágenes y elementos de estilo, asegurando un análisis más preciso del contenido principal.
* **Procesamiento de Texto Avanzado:** Realiza una limpieza exhaustiva del texto, incluyendo la eliminación de caracteres especiales, números irrelevantes y referencias. Aplica tokenización para dividir el texto en palabras, elimina las "stopwords" (palabras comunes sin significado relevante, incluyendo un conjunto específico de términos médicos), y aplica stemming para reducir las palabras a su raíz, facilitando la identificación de conceptos clave.
* **Visualizaciones Enriquecidas:** Genera una variedad de visualizaciones para facilitar la comprensión y comparación de la terminología médica:
    * **Nube de Palabras (Estática e Interactiva):** Representa visualmente los términos médicos más frecuentes, donde el tamaño de la palabra indica su relevancia.
    * **Gráfico de Barras (Interactiva):** Muestra la frecuencia de los términos médicos más comunes en un formato claro y comparativo.
    * **Bigramas (Interactiva):** Identifica y visualiza las asociaciones de dos palabras (bigramas) que ocurren con mayor frecuencia, revelando relaciones importantes entre términos.
    * **Temas Identificados (Interactiva):** Utiliza el modelado de temas (LDA) para descubrir los temas principales presentes en los artículos y los presenta mediante un gráfico sunburst interactivo.
    * **Matriz de Similitud (Interactiva):** Calcula y visualiza la similitud léxica entre los diferentes artículos analizados mediante un mapa de calor interactivo, permitiendo identificar qué artículos comparten una terminología más similar.
    * **Mapa Ontológico (Interactiva):** Genera una red interactiva que representa las relaciones entre los términos médicos clave y los conceptos identificados en los artículos, permitiendo explorar las conexiones semánticas de manera dinámica.
* **Modelado de Temas con LDA:** Emplea la técnica de Latent Dirichlet Allocation (LDA) para identificar los temas subyacentes en el corpus de texto de los artículos, proporcionando una visión de las áreas conceptuales principales.
* **Exportación Detallada de Resultados:** Guarda los resultados del análisis en archivos JSON y CSV, incluyendo las frecuencias de los términos médicos más relevantes, los temas identificados para cada artículo y estadísticas generales del análisis. Los nombres de los archivos incluyen una marca de tiempo para facilitar el seguimiento de diferentes análisis.
* **Interfaz de Usuario Intuitiva:** Ofrece un menú interactivo basado en terminal que permite a los usuarios seleccionar fácilmente los artículos de Wikipedia para analizar, ya sea a partir de una lista predefinida de enfermedades comunes o ingresando las URLs de los artículos deseados manualmente.
* **Análisis Comparativo Robusto:** Permite analizar múltiples artículos simultáneamente, identificando términos compartidos entre ellos y visualizando las similitudes y diferencias en su terminología.
* **Configuración Específica para el Dominio Médico:** Incorpora un conjunto predefinido de "stopwords" médicos comunes, además de las stopwords generales en español, para asegurar que el análisis se centre en los términos más significativos del ámbito médico.

## 🛠️ Requisitos

Antes de comenzar, asegúrate de tener Python instalado en tu sistema.

## ⚙️ Instalación de Librerías

Si alguna de las siguientes librerías no está instalada en tu entorno de Python, puedes instalarlas utilizando la celda que hay dedicada para ello:

```bash
pip install requests
pip install beautifulsoup4
pip install nltk
pip install gensim
pip install scikit-learn
pip install matplotlib
pip install wordcloud
pip install plotly
pip install bokeh
pip install networkx
pip install pyvis
pip install pandas
pip install numpy
Nota sobre NLTK: Después de instalar nltk, es posible que necesites descargar recursos adicionales para el procesamiento del lenguaje natural en español. Abre un intérprete de Python y ejecuta los siguientes comandos:

Python

import nltk
nltk.download('stopwords')
nltk.download('punkt')

🚀 ¿Cómo poner en marcha el Analizador?
Guarda el script: Asegúrate de haber guardado el código del analizador en un archivo Python (por ejemplo, AI_E7_Ivan_Duarte_Pacheco.ipynb).

Abre tu terminal: Abre la línea de comandos o terminal en tu sistema operativo.

Navega al directorio: Utiliza el comando cd para moverte hasta la carpeta donde guardaste el archivo AI_E7_Ivan_Duarte_Pacheco.ipynb.

Ejecuta el script: Una vez en el directorio correcto, ejecuta el analizador con el siguiente comando:

Bash

AI_E7_Ivan_Duarte_Pacheco.ipynb

Sigue el menú interactivo: El programa se iniciará y mostrará un menú en la terminal. Sigue las instrucciones para seleccionar los artículos médicos de Wikipedia que deseas analizar y comparar. Puedes elegir entre las opciones predefinidas o ingresar URLs manualmente.

Espera el análisis: Una vez que hayas seleccionado los artículos, el analizador comenzará a descargar, procesar y analizar el contenido de las páginas de Wikipedia. Esto puede llevar unos segundos o minutos dependiendo de la cantidad de artículos y su tamaño.

Visualiza los resultados: Después del análisis, se generarán diversas visualizaciones. Las visualizaciones interactivas (nube de palabras, gráficos de barras, bigramas, temas, matriz de similitud y mapa ontológico) se abrirán en tu navegador web. Las visualizaciones estáticas (como la nube de palabras con Matplotlib) se mostrarán directamente en la ventana de la terminal o como ventanas separadas.

Consulta los archivos exportados: Los resultados detallados del análisis, incluyendo las frecuencias de términos y los temas identificados para cada artículo, se guardarán en archivos JSON y CSV (con marcas de tiempo en sus nombres) en el mismo directorio donde ejecutaste el script.

Explora el mapa ontológico: El mapa ontológico interactivo, que muestra las relaciones entre los términos médicos, se guardará como un archivo HTML (mapa_ontologico.html) en el directorio del proyecto y se abrirá automáticamente en tu navegador. Puedes interactuar con este mapa haciendo clic, arrastrando y haciendo zoom para explorar las conexiones.

📂 Estructura del Código
Configuración Inicial: Importa las bibliotecas necesarias y define parámetros iniciales, incluyendo listas de stopwords médicos y paletas de colores para las visualizaciones.
Funciones Base: Contiene funciones fundamentales para la descarga de texto de Wikipedia (obtener_texto_wikipedia), la descarga de recursos de NLTK (setup_nltk) y el procesamiento avanzado del texto (procesar_texto).
Visualización de Datos - Versiones Mejoradas: Incluye funciones para generar visualizaciones informativas e interactivas de los datos analizados (mostrar_nube, mostrar_barras, mostrar_bigramas, mostrar_temas).
Análisis de Temas (LDA): Implementa la función detectar_temas para identificar los temas principales en el texto utilizando el modelo LDA de la librería Gensim.
Exportación de Resultados: La función exportar_resultados guarda los resultados del análisis en archivos JSON y CSV.
Análisis Comparativo - Versión Mejorada: La función analizar_correlacion calcula y visualiza la similitud entre los artículos analizados utilizando la técnica TF-IDF y un mapa de calor interactivo con Plotly.
Visualización de Ontologías - Versión Mejorada: La función generar_mapa_ontologico crea un mapa interactivo de relaciones conceptuales entre los términos clave de los artículos utilizando las librerías NetworkX y PyVis.
Ejecución Principal: Define las funciones analizar_articulo para el análisis individual, analizar_articulos para el análisis comparativo y menu_principal para la interfaz de usuario interactiva. La función main orquesta la ejecución del programa.
🤝 Contribuciones
Este proyecto es de código abierto y las contribuciones son bienvenidas. Si deseas mejorar el analizador, agregar nuevas funcionalidades, corregir errores o optimizar el rendimiento, no dudes en contactar conmigo.

📜 Licencia
Este analizador comparativo de terminología médica se distribuye bajo una licencia de código abierto que permite su uso, modificación y distribución libre para fines personales, académicos o profesionales. Se agradece la atribución si utilizas o adaptas este código en tus propios proyectos.

✨ Autor
Iván Duarte Pacheco🚀
